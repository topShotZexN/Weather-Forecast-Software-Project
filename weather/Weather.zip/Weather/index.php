<!DOCTYPE html>
<head><title>Weather Report Using api - hackerrahul.com</title>

</head>

<body>

<center>

	<a href="http://blog.hackerrahul.com">HackerRahul's Blog</a>/<a href="http://hackerrahul.com">HackerRahul Portfolio</a>/
	<a href="http://blog.hackerrahul.com/contact-us">Contact Me!</a>
	<a href="https://www.youtube.com/channel/UCThD9sEw37dndHMyFCXPFVQ">/Subscribe Me on Youtube</a>

	</center>
	<center><br><br>
		<form method="GET" action="get.php">
		<h1>Type City and Country</h1>
		<br><p>For Example Delhi,in</p>
			<input type="text" name="q" required>
			<input type="submit" name="submit">
		</form>
	</center>
</body>
</html>